﻿using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    [Header("Jump Settings")]
    public float jumpForce = 5f;
    public Transform groundCheck;
    public float groundCheckRadius = 0.2f;
    public LayerMask groundLayer;

    [Header("Duck Settings")]
    public Vector2 duckColliderSize = new Vector2(0.2322116f, 0.2424384f);
    public Vector2 duckColliderOffset = new Vector2(0.03228313f, 0.0925616f);

    [Header("Walk Settings")]
    public float walkForce = 1f;

    private Rigidbody2D rb;
    private BoxCollider2D boxCollider;

    private Vector2 originalColliderSize;
    private Vector2 originalColliderOffset;

    private int JumpCount = 0;
    private int MaxJump = 2;
    private bool isGrounded;
    private bool isDucking;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        boxCollider = GetComponent<BoxCollider2D>();

        originalColliderSize = boxCollider.size;
        originalColliderOffset = boxCollider.offset;
    }

    void Update()
    {
        HandleJump();
        HandleDuck();
        HandleLateral();
    }

    void OnCollisionStay2D(Collision2D collision)
    {
        if (collision.collider.CompareTag("Ground"))
        {
            JumpCount = 0;
            isGrounded = true;
        }
    }

    void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.collider.CompareTag("Ground"))
        {
            isGrounded = false;
        }
    }

    void HandleJump()
    {
        if (Input.GetKeyDown(KeyCode.W) && JumpCount<MaxJump && !isDucking)
        {
            rb.velocity = new Vector2(rb.velocity.x, jumpForce);
            JumpCount++;
        }
    }

    void HandleDuck()
    {
        if ((Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow)) && isGrounded)
        {
            if (!isDucking)
            {
                boxCollider.size = duckColliderSize;
                boxCollider.offset = duckColliderOffset;
                isDucking = true;
            }
        }
        else if (isDucking)
        {
            boxCollider.size = originalColliderSize;
            boxCollider.offset = originalColliderOffset;
            isDucking = false;
        }
    }

    void HandleLateral()
    {
        if (Input.GetKey(KeyCode.D))
        {
            rb.velocity = new Vector2(walkForce, rb.velocity.y);
        }
        if (Input.GetKey(KeyCode.A))
        {
            rb.velocity = new Vector2(-walkForce, rb.velocity.y);
        }
    }
}
