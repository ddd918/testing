﻿using UnityEngine;

public class BuildingSpawner : MonoBehaviour
{
    private float maxTime = 5f;
    private float heightRange = 0.45f;
    public GameObject Building;

    private float timer = 0f;

    void Start()
    {
        SpawnBuilding();
    }

    void update()
    {
        if(timer > maxTime)
        {
            SpawnBuilding();
            timer = 0f;
        }
        timer += Time.deltaTime;
    }

    private void SpawnBuilding()
    {
        Vector3 spawnPos = transform.position + new Vector3(0, Random.Range(-heightRange, heightRange));
        GameObject pipe = Instantiate(Building, spawnPos, Quaternion.identity);

        Destroy(Building, 10f);
    }
}
