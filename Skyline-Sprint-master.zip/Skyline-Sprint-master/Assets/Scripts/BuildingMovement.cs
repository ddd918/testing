﻿using UnityEngine;

public class BuildingMovement : MonoBehaviour
{
    void Start()
    {
        
    }

    void Update()
    {
        
    }
}
